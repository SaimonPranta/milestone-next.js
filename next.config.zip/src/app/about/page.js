import Nav from '@/components/Header/Nav';
import React from 'react';

const Page = () => {
    return (
        <div>
            <Nav/>
            <h2>This is About Page</h2>
        </div>
    );
};

export default Page;