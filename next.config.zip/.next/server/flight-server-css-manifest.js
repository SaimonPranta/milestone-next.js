self.__RSC_CSS_MANIFEST={
  "cssImports": {},
  "cssModules": {}
}