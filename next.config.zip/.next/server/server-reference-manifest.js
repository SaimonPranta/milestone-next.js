self.__RSC_SERVER_MANIFEST={
  "node": {},
  "edge": {}
}